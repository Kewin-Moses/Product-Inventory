from decimal import Decimal

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db.models import Count, F, Sum, DecimalField, ExpressionWrapper
from django.db.models.functions import Coalesce
from django.shortcuts import get_object_or_404, redirect, render
from django.db.models.deletion import ProtectedError

from .forms import CategoryForm, LoginForm, ProductForm, RegisterForm
from .models import Category, Product, StockTransaction


@login_required
def dashboard(request):
    total_products = Product.objects.count()
    total_categories = Category.objects.count()
    total_inventory_value = sum((p.inventory_value for p in Product.objects.all()), Decimal('0.00'))
    low_stock_count = Product.objects.filter(quantity__gt=0, quantity__lte=F('reorder_level')).count()
    out_of_stock_count = Product.objects.filter(quantity=0).count()

    context = {
        'total_products': total_products,
        'total_categories': total_categories,
        'total_inventory_value': total_inventory_value,
        'low_stock_count': low_stock_count,
        'out_of_stock_count': out_of_stock_count,
    }
    return render(request, 'inventory/dashboard.html', context)


def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    form = RegisterForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save(commit=False)
        user.set_password(form.cleaned_data['password'])
        user.save()
        messages.success(request, 'Registration successful. Please login.')
        return redirect('login')
    return render(request, 'inventory/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    form = LoginForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = authenticate(
            request,
            username=form.cleaned_data['username'],
            password=form.cleaned_data['password'],
        )
        if user is not None:
            login(request, user)
            return redirect('dashboard')
        messages.error(request, 'Invalid username or password.')
    return render(request, 'inventory/login.html', {'form': form})


def logout_view(request):
    if request.method == 'POST':
        logout(request)
    return redirect('login')


@login_required
def product_list(request):
    products = Product.objects.select_related('category').all().order_by('product_id')
    search = request.GET.get('search', '').strip()
    search_type = request.GET.get('search_type', 'product_id')

    if search:
        if search_type == 'product_id':
            products = products.filter(product_id__icontains=search)
        elif search_type == 'product_name':
            products = products.filter(product_name__icontains=search)
        elif search_type == 'category':
            products = products.filter(category__name__icontains=search)
        elif search_type == 'brand':
            products = products.filter(brand__icontains=search)

    return render(request, 'inventory/product_list.html', {
        'products': products,
        'search': search,
        'search_type': search_type,
    })


@login_required
def product_create(request):
    form = ProductForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        product = form.save()
        if product.quantity > 0:
            StockTransaction.objects.create(
                product=product,
                transaction_type='IN',
                quantity=product.quantity,
                note='Opening stock',
            )
        messages.success(request, 'Product added successfully.')
        return redirect('product_list')
    return render(request, 'inventory/product_form.html', {'form': form, 'title': 'Add Product'})


@login_required
def product_update(request, pk):
    product = get_object_or_404(Product, pk=pk)
    old_quantity = product.quantity
    form = ProductForm(request.POST or None, instance=product)

    if request.method == 'POST' and form.is_valid():
        product = form.save()
        quantity_difference = product.quantity - old_quantity

        if quantity_difference != 0:
            StockTransaction.objects.create(
                product=product,
                transaction_type='ADJUSTMENT',
                quantity=quantity_difference,
                note='Quantity changed from Product Update',
            )

        messages.success(request, 'Product updated successfully.')
        return redirect('product_list')

    return render(request, 'inventory/product_form.html', {
        'form': form,
        'title': 'Update Product',
        'product': product,
    })


@login_required
def category_list(request):
    categories = Category.objects.annotate(product_count=Count('products')).order_by('name')
    return render(request, 'inventory/category_list.html', {'categories': categories})


@login_required
def category_create(request):
    form = CategoryForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Category added successfully.')
        return redirect('category_list')
    return render(request, 'inventory/category_form.html', {'form': form, 'title': 'Add Category'})


@login_required
def category_update(request, pk):
    category = get_object_or_404(Category, pk=pk)
    form = CategoryForm(request.POST or None, instance=category)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Category updated successfully.')
        return redirect('category_list')
    return render(request, 'inventory/category_form.html', {'form': form, 'title': 'Update Category'})


@login_required
def category_delete(request, pk):
    category = get_object_or_404(Category, pk=pk)
    if request.method == 'POST':
        try:
            category.delete()
            messages.success(request, 'Category deleted successfully.')
        except ProtectedError:
            messages.error(request, 'This category cannot be deleted because products use it.')
    return redirect('category_list')


def _stock_form(request, title, transaction_type):
    products = Product.objects.select_related('category').order_by('product_id')

    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        quantity_text = request.POST.get('quantity', '').strip()
        note = request.POST.get('note', '').strip()
        product = get_object_or_404(Product, pk=product_id)

        try:
            quantity = int(quantity_text)
            if quantity <= 0:
                raise ValueError
        except (TypeError, ValueError):
            messages.error(request, 'Quantity must be a positive whole number.')
            return render(request, 'inventory/stock_form.html', {
                'products': products, 'title': title, 'transaction_type': transaction_type,
            })

        if transaction_type == 'OUT' and quantity > product.quantity:
            messages.error(request, 'Stock Out quantity cannot be greater than current stock.')
            return render(request, 'inventory/stock_form.html', {
                'products': products, 'title': title, 'transaction_type': transaction_type,
            })

        if transaction_type == 'IN':
            product.quantity += quantity
        else:
            product.quantity -= quantity

        product.save()
        StockTransaction.objects.create(
            product=product,
            transaction_type=transaction_type,
            quantity=quantity,
            note=note,
        )
        messages.success(request, f'{title} completed successfully.')
        return redirect('current_stock')

    return render(request, 'inventory/stock_form.html', {
        'products': products, 'title': title, 'transaction_type': transaction_type,
    })


@login_required
def stock_in(request):
    return _stock_form(request, 'Stock In', 'IN')


@login_required
def stock_out(request):
    return _stock_form(request, 'Stock Out', 'OUT')


@login_required
def stock_adjustment(request):
    products = Product.objects.select_related('category').order_by('product_id')
    if request.method == 'POST':
        product = get_object_or_404(Product, pk=request.POST.get('product_id'))
        quantity_text = request.POST.get('quantity', '').strip()
        note = request.POST.get('note', '').strip()
        try:
            adjustment = int(quantity_text)
            if adjustment == 0:
                raise ValueError
        except (TypeError, ValueError):
            messages.error(request, 'Adjustment must be a non-zero whole number. Use a negative number to reduce stock.')
            return render(request, 'inventory/adjustment_form.html', {'products': products})

        new_quantity = product.quantity + adjustment
        if new_quantity < 0:
            messages.error(request, 'Adjustment cannot make stock negative.')
            return render(request, 'inventory/adjustment_form.html', {'products': products})

        product.quantity = new_quantity
        product.save()
        StockTransaction.objects.create(
            product=product,
            transaction_type='ADJUSTMENT',
            quantity=adjustment,
            note=note,
        )
        messages.success(request, 'Stock adjustment completed successfully.')
        return redirect('current_stock')

    return render(request, 'inventory/adjustment_form.html', {'products': products})


@login_required
def current_stock(request):
    products = Product.objects.select_related('category').order_by('product_id')
    return render(request, 'inventory/current_stock.html', {'products': products})


@login_required
def stock_report(request):
    products = Product.objects.select_related('category').order_by('product_id')
    return render(request, 'inventory/report.html', {
        'title': 'Stock Report',
        'products': products,
        'report_type': 'stock',
    })


@login_required
def low_stock_report(request):
    products = Product.objects.select_related('category').filter(
        quantity__gt=0, quantity__lte=F('reorder_level')
    ).order_by('quantity')
    return render(request, 'inventory/report.html', {
        'title': 'Low Stock Report',
        'products': products,
        'report_type': 'stock',
    })


@login_required
def out_of_stock_report(request):
    products = Product.objects.select_related('category').filter(quantity=0).order_by('product_id')
    return render(request, 'inventory/report.html', {
        'title': 'Out of Stock Report',
        'products': products,
        'report_type': 'stock',
    })


@login_required
def category_report(request):
    value_expression = ExpressionWrapper(
        F('products__quantity') * F('products__purchase_price'),
        output_field=DecimalField(max_digits=15, decimal_places=2),
    )
    categories = Category.objects.annotate(
        product_count=Count('products', distinct=True),
        total_quantity=Coalesce(Sum('products__quantity'), 0),
        inventory_value=Coalesce(Sum(value_expression), Decimal('0.00')),
    ).order_by('name')
    return render(request, 'inventory/summary_report.html', {
        'title': 'Category-wise Report',
        'rows': categories,
        'report_type': 'category',
    })


@login_required
def brand_report(request):
    value_expression = ExpressionWrapper(
        F('quantity') * F('purchase_price'),
        output_field=DecimalField(max_digits=15, decimal_places=2),
    )
    brands = Product.objects.values('brand').annotate(
        product_count=Count('id'),
        total_quantity=Coalesce(Sum('quantity'), 0),
        inventory_value=Coalesce(Sum(value_expression), Decimal('0.00')),
    ).order_by('brand')
    return render(request, 'inventory/summary_report.html', {
        'title': 'Brand-wise Report',
        'rows': brands,
        'report_type': 'brand',
    })


@login_required
def inventory_value_report(request):
    products = Product.objects.select_related('category').order_by('product_id')
    total_value = sum((p.inventory_value for p in products), Decimal('0.00'))
    return render(request, 'inventory/inventory_value_report.html', {
        'title': 'Inventory Value Report',
        'products': products,
        'total_value': total_value,
    })
