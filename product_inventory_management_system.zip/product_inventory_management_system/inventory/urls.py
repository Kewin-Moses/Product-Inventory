from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    path('products/', views.product_list, name='product_list'),
    path('products/add/', views.product_create, name='product_create'),
    path('products/<int:pk>/edit/', views.product_update, name='product_update'),

    path('categories/', views.category_list, name='category_list'),
    path('categories/add/', views.category_create, name='category_create'),
    path('categories/<int:pk>/edit/', views.category_update, name='category_update'),
    path('categories/<int:pk>/delete/', views.category_delete, name='category_delete'),

    path('stock/in/', views.stock_in, name='stock_in'),
    path('stock/out/', views.stock_out, name='stock_out'),
    path('stock/adjustment/', views.stock_adjustment, name='stock_adjustment'),
    path('stock/', views.current_stock, name='current_stock'),

    path('reports/stock/', views.stock_report, name='stock_report'),
    path('reports/low-stock/', views.low_stock_report, name='low_stock_report'),
    path('reports/out-of-stock/', views.out_of_stock_report, name='out_of_stock_report'),
    path('reports/category/', views.category_report, name='category_report'),
    path('reports/brand/', views.brand_report, name='brand_report'),
    path('reports/inventory-value/', views.inventory_value_report, name='inventory_value_report'),
]
